{{-- Chama a template pré pronta --}}
@extends('courses.panel_template')

@section('courseContent')
    @parent
    <div id="course-modules" class="pt-3">
      <p>Nada por aqui no momento.
		</div>
@endsection
