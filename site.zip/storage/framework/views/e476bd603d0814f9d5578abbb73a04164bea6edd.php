<?php $__env->startSection('viewMain'); ?>
    ##parent-placeholder-7ba1feefd9b0e2b57ed1d8023f4f47e24fdb610c##
    <nav aria-label="breadcrumb" id="page-nav">
    	<div class="container">
    		<ol class="breadcrumb">
    			<li class="breadcrumb-item">
    				<a href="<?php echo e(URL::route('posts.index')); ?>">
    					<?php echo e(__('messages.posts')); ?>

    				</a>
    			</li>
    			<li class="breadcrumb-item active" aria-current="page">
    				<?php echo e(__('messages.create_post')); ?>

    			</li>
    		</ol>
    	</div>
    </nav>

    <div class="jumbotron jumbotron-fluid">
    	<div class="container">
    		<h1 class="display-4">
    			<?php echo e(__('messages.create_post')); ?>

    		</h1>
    	</div>
    </div>


    <div class="container">

    	<?php
    		if (session('success')){
    			if (session('success')['success'] == false){
    				echo '<div class="alert alert-danger" role="alert">' . session('success')['messages'] . '</div>';
    			} else {
    				echo '<div class="alert alert-success" role="alert">' . session('success')['messages'] . '</div>';
    			}
    		}
    	?>

    	<div class="row">
    		<form class="col-12" method="post" action="<?php echo e(URL::route('posts.store')); ?>" enctype="multipart/form-data">
    			<div class="row">
    			<div class="col-9">

    					<div class="form-group">
    						<label for="txtTitle">Título</label>
    						<input type="text" class="form-control" id="txtTitle" placeholder="Título" name="title">
    					</div>

    					<div class="form-group">
    						<textarea type="text" class="form-control tinymce" rows="8" id="txtContent" placeholder="Conteúdo" name="content"></textarea>
    					</div>

    					<div class="form-group">
    						<label for="txtTitle">Resumo</label>
    						<textarea class="form-control" id="txtTitle" placeholder="Resumo" name="resume"></textarea>
    					</div>

              <div class="form-group">
                <label for="txtAuthor">Author</label>
                <input type="text" class="form-control" id="txtAuthor" disabled value="<?php echo e(Auth::user()->firstname . ' ' . Auth::user()->lastname); ?>"></input>
              </div>
    			</div>

    				<div class="col-3">

    					<button type="submit" class="btn btn-primary btn-lg btn-block mt-3">Adicionar</button>

    					<div class="card mt-3">
    					  <h5 class="card-header">Tags</h5>
    					  <div class="card-body">
                  <p>Digite as tags separadas por vírgula.</p>
    						  <input type="text" data-role="tagsinput" placeholder="Adicionar +" name="tags">
    					  </div>
    					</div>

    					<div class="card mt-3">
    					  <h5 class="card-header">Categoria</h5>
							  <div class="card-body">
									<select name="category_id">
										<option value="0" disabled selected>Sem categoria</option>
										<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($category['id']); ?>"><?php echo e($category['name']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
							  </div>
    					</div>

    					<div class="card mt-3">
    					  <h5 class="card-header">Thumbnail</h5>
    					  <div class="card-body">
                  <div class="input-group">
                     <span class="input-group-btn">
                       <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
                         <i class="fa fa-picture-o"></i> Choose
                       </a>
                     </span>
                     <input id="thumbnail" class="form-control" type="text" name="filepath">
                   </div>
                   <img id="holder" style="margin-top:15px;max-height:100px;">
    					  </div>
    					</div>
    				</div>
    			</div>
    			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    		</form>
    	</div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.templates.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>