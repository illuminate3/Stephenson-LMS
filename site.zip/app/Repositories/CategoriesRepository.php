<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CategoriesRepository
 * @package namespace App\Repositories;
 */
interface CategoriesRepository extends RepositoryInterface
{
    //
}
