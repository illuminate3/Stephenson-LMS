	<title>
		<?php echo e($title); ?>

	</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1" />
	<meta name="csrf-token" content="<?php echo csrf_token(); ?>">
	<link rel="stylesheet" href="<?php echo asset("assets/admin/css/material-icons.css"); ?>" >
	<link rel="stylesheet" href="<?php echo asset("assets/admin/css/bootstrap.min.css"); ?>" >
	<link rel="stylesheet" href="<?php echo asset("assets/admin/css/bootstrap-tagsinput.css"); ?>" >
	<link rel="stylesheet" href="<?php echo asset("assets/admin/css/layout.css"); ?>">
