


<?php $__env->startSection('viewMain'); ?>
    ##parent-placeholder-7ba1feefd9b0e2b57ed1d8023f4f47e24fdb610c##
    <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <h1 class="display-4"><?php echo e($course->title); ?></h1>
      </div>
    </div>

    <div class="container">
    	<div class="row">
    		<div class="col-3">

    			<div class="card" id="course-sidebar">
    				<img class="card-img-top" src="<?php echo e($course->cover); ?>">

    				<div class="card-body">
    				<?php if(auth()->guard()->check()): ?>
    					<form method="post" action="<?php echo e(URL::route('courses.enter_course', ['course_id' => $course->id, 'user_id' => Auth::user()->id, 'type' => 2])); ?>">
    						<button class="btn btn-primary btn-block" type="submit">Entrar no Curso</button>
    						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    					</form>
    				<?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
    					<a href="<?php echo e(URL::route('login')); ?>" class="btn btn-primary btn-block">Entrar no Curso</a>
    				<?php endif; ?>
    				<div id="course-info">
    					<div class="info"><i class="ion-ios-person-outline"></i><a href="<?php echo e(URL::route('profile.profile', ['id' => $course->author->id])); ?>"><?php echo e($course->author->firstname . " " . $course->author->lastname); ?></a></div>
    					<div class="info"><i class="ion-ios-folder-outline"></i><?php echo e(count($course->getModules)); ?> módulos</div>
    					<div class="info"><i class="ion-ios-videocam-outline"></i><?php echo e(count($course->getLessons)); ?> aulas</div>
    				</div>
    				</div>
    			</div>
    		</div>

    		<div class="col-9">
    			<?php if($course->description == null): ?>
    				<p>Nenhuma descrição disponível para este curso.</p>
    			<?php else: ?>
            <?php echo $course->description; ?>

          <?php endif; ?>
    		</div>
    	</div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>