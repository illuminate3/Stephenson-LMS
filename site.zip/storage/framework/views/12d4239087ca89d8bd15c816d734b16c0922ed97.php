<?php $__env->startSection('viewMain'); ?>
    ##parent-placeholder-7ba1feefd9b0e2b57ed1d8023f4f47e24fdb610c##
    <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <h1 class="display-4 pb-2"><?php echo e($tutorial->title); ?></h1>
		<b>Tags:</b> <?php echo e($tutorial->tags); ?>

      </div>
    </div>
	
	

    <div class="container">
		<ul class="post-info list-inline">
			<li class="list-inline-item"><i class="ion-person"></i><a href="<?php echo e(URL::route('profile.profile', ['user' => $tutorial->author->user])); ?>"><?php echo e($tutorial->author->firstname); ?></a></li>
			<li class="list-inline-item"><i class="ion-calendar"></i><?php echo e($tutorial->created_at); ?></li>
			<li class="list-inline-item"><i class="ion-pricetags"></i><?php echo e($tutorial->category->name); ?></li>
		</ul>
		
      <div class="embed-responsive embed-responsive-16by9">
        <?php echo $video_embed; ?>

      </div>
	  
	  <?php echo $tutorial->description; ?>

			<div id="comments-area" class="mt-5">
				<h3>Comentários</h3>
				<hr>
				<?php if(auth()->guard()->check()): ?>
				<div id="comment-box">
				<form method="post" action="<?php echo e(URL::route('comment.store')); ?>">
					<div class="form-group">
						<label for="comment-textarea">Publicar um Comentário</label>
						<textarea class="form-control" id="comment-textarea" rows="3" name="content"></textarea>
					</div>

					<button class="btn btn-primary float-right">Publicar</button>

					<input type="hidden" name="author_id" value="<?php echo e(Auth::user()->id); ?>">
					<input type="hidden" name="post_id" value="<?php echo e($tutorial->id); ?>">
					<input type="hidden" name="post_type" value="tutorial">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<div class="clearfix"></div>
				</form>
				</div>

				<div class="mt-5" id="comments">
					<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<div class="media mt-4">
							<?php if($comment->author->avatar == null): ?>
								<img style="height:64px;"class="align-self-start mr-3" src="<?php echo e(asset('assets/images/avatar-default.png')); ?>">
							<?php else: ?>
								<img style="height:64px;" class="align-self-start mr-3" src="/uploads/avatars/<?php echo e($comment->author->avatar); ?>">
							<?php endif; ?>

						<div class="media-body">
							<a href="<?php echo e(URL::route('profile.profile', ['profile' => $comment->author->user])); ?>">
								<h5><?php echo e($comment->author->firstname . " " . $comment->author->lastname); ?></h5>
							</a>
							<p><?php echo e($comment->content); ?></p>
						</div>
					</div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
				<?php if(auth()->guard()->guest()): ?>
				<p>É necessário estar logado para comentar. <a href="<?php echo e(URL::to('/login')); ?>">Fazer login</a></p>
				<?php endif; ?>
				</div>
			</div>
    </div>
	
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>