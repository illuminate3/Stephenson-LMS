<?php $__env->startSection('viewMain'); ?>
    ##parent-placeholder-7ba1feefd9b0e2b57ed1d8023f4f47e24fdb610c##
    <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <h1 class="display-4">Entrar</h1>
      </div>
    </div>

    <div class="container">
		<?php if(session('login_message') and session('success')['login_message'] == false): ?>
				<div class="alert alert-danger" role="alert"><?php echo e(session('login_message')['messages']); ?></div>
		<?php endif; ?>

    <form method="post" action="<?php echo e(URL::route('login')); ?>">
      <div class="form-group">
        <label for="input-email">E-mail</label>
        <input name="login_email" type="email" class="form-control" id="input-email" placeholder="E-mail">
      </div>
      <div class="form-group">
        <label for="input-password">Senha</label>
        <input name="login_senha" type="password" class="form-control" id="input-password" placeholder="Senha">
      </div>
      <div class="form-check">
        <input name="login_rememberme" type="checkbox" class="form-check-input" id="input-rememberme">
        <label class="form-check-label" for="input-rememberme">Matenha-me Conectado</label>
      </div>
      <button type="submit" class="btn btn-primary">Entrar</button>
    	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>