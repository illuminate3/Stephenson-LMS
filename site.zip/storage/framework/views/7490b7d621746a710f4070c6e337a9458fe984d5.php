<!DOCTYPE html>
<html>
<head>
<?php echo $__env->make('admin.templates.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
    <?php echo $__env->make('admin.templates.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div id="content">
        <!-- DIVISA DE CONTEUDO -->
        <?php $__env->startSection('viewMain'); ?>
            <?php echo $__env->yieldSection(); ?>
    
    <?php echo $__env->make('admin.templates.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 </div>
</body>
</html>