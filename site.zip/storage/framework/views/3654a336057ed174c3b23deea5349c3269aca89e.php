<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset("assets/css/bootstrap.min.css")); ?>">
<link rel="stylesheet" href="<?php echo e(asset("assets/css/style.css")); ?>">
<title><?php echo e($title); ?></title>
