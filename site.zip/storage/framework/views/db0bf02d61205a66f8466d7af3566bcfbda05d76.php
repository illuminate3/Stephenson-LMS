<?php $__env->startSection('viewMain'); ?>
    ##parent-placeholder-7ba1feefd9b0e2b57ed1d8023f4f47e24fdb610c##
		<div class="jumbotron jumbotron-fluid">
		  <div class="container">
			 <h1 class="display-4"><?php echo e(__('messages.dashboard')); ?></h1>
		  </div>
		</div>

		<div class="container">
			<div class="row">
				<div class="col">
					<div class="card card-statistic">
						<div class="row">
							<div class="col-6 card-statistic-title">
								<i class="material-icons">people</i>
								<div><?php echo e(__('messages.users')); ?></div>
							</div>

							<div class="col-6"><p><?php echo e(count($users)); ?></p></div>
						</div>
					</div>
				</div>
				<div class="col">
					<div class="card card-statistic">
						<div class="row">
							<div class="col-6 card-statistic-title">
								<i class="material-icons">video_library</i>
								<div><?php echo e(__('messages.tutorials')); ?></div>
							</div>

							<div class="col-6"><p><?php echo e(count($tutorials)); ?></p></div>
						</div>
					</div>
				</div>

				<div class="col">
					<div class="card card-statistic">
						<div class="row">
							<div class="col-6 card-statistic-title">
								<i class="material-icons">star</i>
								<div><?php echo e(__('messages.courses')); ?></div>
							</div>

							<div class="col-6"><p><?php echo e(count($courses)); ?></p></div>
						</div>
					</div>
				</div>

				<div class="col">
					<div class="card card-statistic">
						<div class="row">
							<div class="col-6 card-statistic-title">
								<i class="material-icons">insert_drive_file</i>
								<div><?php echo e(__('messages.pages')); ?></div>
							</div>

							<div class="col-6"><p><?php echo e(count($pages)); ?></p></div>
						</div>
					</div>
				</div>

			</div>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.templates.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>