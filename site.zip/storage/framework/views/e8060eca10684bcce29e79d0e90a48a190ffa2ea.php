<?php $__env->startSection('viewMain'); ?>
    ##parent-placeholder-7ba1feefd9b0e2b57ed1d8023f4f47e24fdb610c##
    <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <h1 class="display-4">Meus Cursos</h1>
      </div>
    </div>

    <div class="container">
    	<ul class="nav nav-tabs mb-3">
    		<li class="nav-item">
    			<a class="nav-link <?php echo e(($loop == "studying") ? "active" : null); ?>" href="<?php echo e(URL::route('courses.user_courses')); ?>">Cursando</a>
    		</li>

    		<li class="nav-item">
    			<a class="nav-link <?php echo e(($loop == "favorites") ? "active" : null); ?>" href="<?php echo e(URL::route('courses.user_favorite_courses')); ?>">Favoritos</a>
    		</li>
    	</ul>

    	<?php if(count($courses) > 0): ?>
    		<div class="row">
    			<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    				<div class="col-3">
    					<div class="card">
    							<?php if($course->course->cover == NULL): ?>
    								<img class="card-img-top" src="<?php echo e(asset("assets/images/thumbnail-default.jpg")); ?>" alt="<?php echo e($course['title']); ?>">
    							<?php else: ?>
    								<img class="card-img-top" src="<?php echo e(asset($course->course->cover)); ?>" alt="<?php echo e($course['title']); ?>">
    							<?php endif; ?>
    						<div class="card-body">
    						<h5 class="card-title"><?php echo e($course->course->title); ?></h5>
    						<p class="card-text"><?php echo e($course->course->resume); ?></p>
    						<a href="<?php echo e(URL::route('courses.single', ['course' => $course->course->id])); ?>" class="btn btn-primary">Ver</a>
    						</div>
    					</div>
    				</div>
    			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		</div>
    	<?php else: ?>
    		<?php if($loop == "studying"): ?>
    			<p>Você não está cursando nenhum curso atualmente.</p>
    		<?php else: ?>
    			<p>Você não favoritou nenhum curso.</p>
    		<?php endif; ?>
    	<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>