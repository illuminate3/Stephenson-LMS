


<?php $__env->startSection('viewMain'); ?>
    ##parent-placeholder-7ba1feefd9b0e2b57ed1d8023f4f47e24fdb610c##
		<?php echo view('profile/sidebar-profile', ['user' => $user, 'isLoggedProfile' => $isLoggedProfile ]); ?>

		<div class="col s9" id="profile-content">
			<h2 class="profile-page-title">Feed</h2>
			<hr>
			<?php if ($isLoggedProfile){ ?>
			  <form method="post" action="<?php echo URL::route('post.store'); ?>">
				  <div class="form-group">
					 <textarea name="data" class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Alguma novidade que deseja compartilhar?"></textarea>
				  </div>

				  <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
				  <button type="submit" class="btn btn-primary float-right">Publicar</button>
				  <div class="clearfix"></div>
			  </form>
			<?php } ?>

			<ul class="list-unstyled" id="activities">
        <?php  echo var_dump($activities = $user->getActivities());  ?>
			</ul>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>