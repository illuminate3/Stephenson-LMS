		<div class="container mt-5">		
			<hr>
			<p class="text-center p-2">Site desenvolvido com a plataforma Stepherson utilizando o tema Liberty</p>
		</div>

		<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-3.2.1.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
</body>

</html>