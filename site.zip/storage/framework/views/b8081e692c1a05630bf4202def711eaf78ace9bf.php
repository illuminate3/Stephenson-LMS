<?php $__env->startSection('courseContent'); ?>
    ##parent-placeholder-e404b3344a72528b2ca2df4c1aa2a7efdc076727##
		<div id="modules" class="pt-3">
		<?php if(count($course->getModules) > 0): ?>
      <div id="modules-list" class="card">
				<?php  $modules = $course->getModules  ?>
        <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card module">
            <div class="card-header module-header" id="headingOne">
              <h5 class="mb-0">
                <button class="btn btn-link module-name" data-toggle="collapse" data-target="#module-<?php echo e($module->id); ?>" aria-expanded="true" aria-controls="collapseOne">
                  <?php echo e($module->name); ?>

                </button>
              </h5>
            </div>

            <div id="module-<?php echo e($module->id); ?>" class="collapse" data-parent="#modules">
              <div class="card-body">
                <?php if(count($module->getLessons) > 0): ?>
  								<ul class="list-group">
  									<?php  $lessons = $module->getLessons  ?>
                    <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  										<li class="lesson list-group-item">
                          <a href="<?php echo e(URL::route('lesson.view_lesson', ['course_id' => $course->id, 'lesson' => $lesson->id])); ?>">
                          <?php echo e($lesson->title); ?>

                          </a> -
                          <span class="lesson-time"><?php echo e($lesson->time); ?></span>
  										</li>
  									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  								</ul>
  							<?php else: ?>
  								<div class="no-lesson">Nenhuma aula cadastrada nesse módulo.</div>
  							<?php endif; ?>
              </div>
            </div>
          </div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
    <?php else: ?>
			<div class="no-module card">Nenhum módulo criado. Quem sabe mais tarde...</div>
    <?php endif; ?>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('courses.panel_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>