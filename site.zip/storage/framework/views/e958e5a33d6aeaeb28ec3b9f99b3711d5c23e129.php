


<?php $__env->startSection('viewMain'); ?>
    ##parent-placeholder-7ba1feefd9b0e2b57ed1d8023f4f47e24fdb610c##
    <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <h1 class="display-4">Postagens</h1>
      </div>
    </div>

    <div class="container">
    	<?php if(count($posts) > 0): ?>
    	<div class="row">
    		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    			<div class="col-3">
    				<div class="card">
    						<?php if($post['thumbnail'] == NULL): ?>
    							<img class="card-img-top" src="<?php echo e(asset("assets/images/thumbnail-default.jpg")); ?>" alt="<?php echo e($post['title']); ?>">
    						<?php else: ?>
    							<img class="card-img-top" src="<?php echo e(asset($post['thumbnail'])); ?>" alt="<?php echo e($post['title']); ?>">
    						<?php endif; ?>
    					<div class="card-body">
    						<h5 class="card-title"><?php echo e($post['title']); ?></h5>
    						<p class="card-text"><?php echo e($post['resume']); ?></p>
    						<a href="<?php echo e(URL::route('posts.single', ['post' => $post->id])); ?>" class="btn btn-primary">Ver</a>
    					</div>
    				</div>
    			</div>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</div>
    <?php else: ?>
    		<p>Nenhuma postagem cadastrada.</p>
    <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>