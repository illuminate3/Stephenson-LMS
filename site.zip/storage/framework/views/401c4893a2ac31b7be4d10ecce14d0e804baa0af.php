<?php $__env->startSection('courseContent'); ?>
    ##parent-placeholder-e404b3344a72528b2ca2df4c1aa2a7efdc076727##
		<div id="course-modules" class="pt-3">
      <p>Nada por aqui no momento.
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('courses.panel_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>