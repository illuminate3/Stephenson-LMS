<!DOCTYPE html>
<html>
<head>
@include('admin.templates.head')
</head>
<body>
    @include('admin.templates.header')
    <div id="content">
        <!-- DIVISA DE CONTEUDO -->
        @section('viewMain')
            @show
    
    @include('admin.templates.footer')
	 </div>
</body>
</html>