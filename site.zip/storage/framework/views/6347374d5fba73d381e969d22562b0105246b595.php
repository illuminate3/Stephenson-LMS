<!DOCTYPE html>
<html>
<head>
<?php echo $__env->make('head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
    <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div id="content">
        <!-- DIVISA DE CONTEUDO -->
        <?php $__env->startSection('viewMain'); ?>
            <?php echo $__env->yieldSection(); ?>

    <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 </div>
</body>
</html>
