<?php $__env->startSection('viewMain'); ?>
    ##parent-placeholder-7ba1feefd9b0e2b57ed1d8023f4f47e24fdb610c##
    <div class="modal" tabindex="-1" role="dialog" id="add-material-modal" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">

        </div>
      </div>
    </div>

    <nav aria-label="breadcrumb" id="page-nav">
    	<div class="container">
    		<ol class="breadcrumb">
    			<li class="breadcrumb-item">
    				<a href="<?php echo e(URL::route('courses.index')); ?>">
    					<?php echo e(__('messages.courses')); ?>

    				</a>
    			</li>
    			<li class="breadcrumb-item active" aria-current="page">
    				<?php echo e(__('messages.manage_course')); ?>

    			</li>
    		</ol>
    	</div>
    </nav>

    <div class="jumbotron jumbotron-fluid">
    	<div class="container">
    		<h1 class="display-4">
    			<?php echo e(__('messages.manage_course')); ?>

    		</h1>
    	</div>
    </div>

    <div class="container mb-3">
      <ul class="nav nav-tabs">
        <li class="nav-item">
          <a class="nav-link <?php echo e(request()->is('admin/course/{}') ? 'active' : ''); ?>" href="#">Início</a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php echo e(request()->is('admin/course/') ? 'active' : ''); ?>" href="#">Gerenciar</a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php echo e(request()->is('admin/course/{}/edit') ? 'active' : ''); ?>" href="#">Editar</a>
        </li>

        <li class="nav-item <?php echo e(request()->is('admin/course/{}') ? 'active' : ''); ?>">
          <a class="nav-link" href="#">Dúvidas</a>
        </li>
      </ul>
    </div>

    <div class="container">
    	<?php
    		if (session('success')){
    			if (session('success')['success'] == false){
    				echo '<div class="alert alert-danger" role="alert">' . session('success')['messages'] . '</div>';
    			} else {
    				echo '<div class="alert alert-success" role="alert">' . session('success')['messages'] . '</div>';
    			}
    		}
    	?>

    	<?php if(count($course->getModules) > 0): ?>
      	<div id="modules-list">
      		<?php  $modules = $course->getModules  ?>
          <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      		<div class="card module" id="module-<?php echo e($module->id); ?>">
      			<div class="card-header" id="module-heading-<?php echo e($module->id); ?>">
      				<div class="row">
      					<div class="col-1 drag-module">=</div>
      					<h5 class="mb-0 col-8">
      						<button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse-<?php echo e($module->id); ?>" aria-expanded="false" aria-controls="collapse-<?php echo e($module->id); ?>">
      						 <?php echo e($module->name); ?>

      					  </button>
      					</h5>

      					<div class="module-actions col-3">
      						<div class="btn-group action-buttons" role="group">
      							<a href="#">
      							<button type="button" class="btn btn-primary"><i class="material-icons">edit</i></button>
      						</a>

      							<form method="post" action="<?php echo e(URL::route('course.module.destroy', ['course_id' => $course->id, 'module_id' =>  $module['id']])); ?>">
      								<button type="submit" class="btn btn-danger"><i class="material-icons">remove_circle_outline</i></button>
      								<input type="hidden" value="DELETE" name="_method">
      								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      							</form>
      						</div>
      					</div>
      				</div>
      			</div>
      			<div id="collapse-<?php echo e($module->id); ?>" class="collapse" aria-labelledby="module-heading-<?php echo e($module->id); ?>" data-parent="#modules-list">
      				<div class="card-body">
      					<?php if(count($module->getLessons) > 0): ?>
      					<div class="lessons-list">
      						<?php  $lessons = $module->getLessons  ?>
                  <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      						<div class="card lesson" id="lesson-<?php echo e($lesson->id); ?>">
      							<div class="card-header" id="lesson-heading-<?php echo e($lesson->id); ?>">
      								<div class="row">
      									<div class="col-1 drag-lesson">=</div>
      									<h5 class="mb-0 col-8">
      										<button class="btn btn-link collapsed" data-toggle="collapse" data-target="#lesson-collapse-<?php echo e($lesson->id); ?>" aria-expanded="false" aria-controls="collapseTwo">
      											<?php echo e($lesson->title); ?>

      									   </button>
      									</h5>

      									<div class="lesson-actions col-3">
      										<div class="btn-group" role="group" aria-label="Button group with nested dropdown">
      											<a href="<?php echo e(URL::route('course.module.lesson.edit',['course_id' => $course->id, 'module_id' => $module->id, 'lesson_id' => $lesson->id])); ?>">
      												<button type="button" class="btn btn-primary"><i class="material-icons">edit</i></button>
      											</a>
      											<form method="post" action="<?php echo e(URL::route('course.module.lesson.destroy', ['course_id' => $course->id, 'module_id' =>  $module->id, 'lesson_id' => $lesson->id])); ?>">
      												<button type="submit" class="btn btn-danger"><i class="material-icons">remove_circle_outline</i></button>
      												<input type="hidden" value="DELETE" name="_method">
      												<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      											</form>

      											<div class="btn-group" role="group">
      												<button id="add-material-<?php echo e($lesson->id); ?>" type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      												Material
      											 </button>
      												<div class="dropdown-menu" aria-labelledby="add-material-<?php echo e($lesson->id); ?>">
      													<a class="dropdown-item" class="add-material" data-toggle="modal" data-target="#add-material-modal" data-mtype="file" href="#">Arquivo</a>
      													<a class="dropdown-item" class="add-material" data-toggle="modal" data-target="#add-material-modal" data-mtype="image" href="#">Imagem</a>
      													<a class="dropdown-item" class="add-material" data-toggle="modal" data-target="#add-material-modal" data-mtype="video" href="#">Vídeo</a>
      													<a class="dropdown-item" class="add-material" data-toggle="modal" data-target="#add-material-modal" data-mtype="note" href="#">Nota</a>
      													<a class="dropdown-item" class="add-material" data-toggle="modal" data-target="#add-material-modal" data-mtype="poll" href="#">Enquete</a>
      												</div>
      											</div>
      										</div>
      									</div>
      								</div>
      							</div>
      							<div id="lesson-collapse-<?php echo e($lesson->id); ?>" class="collapse" aria-labelledby="lesson-heading-<?php echo e($lesson->id); ?>" data-parent=".lesson-list">
      								<div class="card-body">
      									<?php if(count($lesson->getMaterials) > 0): ?>
      									<div class="materials">
      										<?php  $materials = $lesson->getMaterials  ?>
                          <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      											<div id="material">
      													@switch (<?php echo e($material->type); ?>)
        													@case ("note")
        														<i class='material-icons'>note</i>
        														<?php break; ?>
        													@case ("poll")
        														<i class='material-icons'>question_answer</i>
        														<?php break; ?>
        													@case ("photo")
        														<i class='material-icons'>photo</i>
        														<?php break; ?>
        													@case ("video")
        														<i class='material-icons'>play_arrow</i>
        														<?php break; ?>
                                  @default
      													@endswitch
      												<?php echo e($material->title); ?>

      											</div>
      										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      									</div>
                        <?php else: ?>
                          <p>Nenhum material cadastrado.</p>
                        <?php endif; ?>
      								</div>
      							</div>
      						</div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      					</div>
                <?php else: ?>
                  Nenhuma aula cadastrada
      					<?php endif; ?>
      					<a class="btn btn-primary btn-lg btn-block mt-3" href="<?php echo e(URL::route('course.module.lesson.create',['course_id' => $course->id, 'module_id' => $module->id])); ?>">
      						Criar Aula para este Módulo
      					</a>
      				</div>
      			</div>
      		</div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      	</div>
    	<?php else: ?>
    	   <p>Nenhum módulo criado, crie um usando o formulário abaixo.</p>
    	<?php endif; ?>
  		<div class="card">
  			<div class="card-body">
  				<form class="form-inline" method="post" action="<?php echo e(URL::route('course.module.store',['course_id' => $course->id])); ?>">
  					<div class="form-group">
  						<label for="inlineFormInputName2">Criar um Módulo</label>
  						<input type="text" class="form-control mx-sm-3" id="inlineFormInputName2" placeholder="Nome do Módulo" name="name">
  					</div>
  					<input type="hidden" name="course_id" value="<?php echo e($course['id']); ?>">
  					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
  					<button type="submit" class="btn btn-primary sm-3">Criar</button>

  				</form>
  			</div>
  		</div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.templates.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>