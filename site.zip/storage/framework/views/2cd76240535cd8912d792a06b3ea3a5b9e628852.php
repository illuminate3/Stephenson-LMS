


<?php $__env->startSection('viewMain'); ?>
    ##parent-placeholder-7ba1feefd9b0e2b57ed1d8023f4f47e24fdb610c##
		<nav aria-label="breadcrumb" id="page-nav">
			<div class="container">
				<ol class="breadcrumb">
					<li class="breadcrumb-item active" aria-current="page">Cursos</li>
				</ol>
			</div>
		</nav>

		<div class="jumbotron jumbotron-fluid">
			<div class="container">
				<h1 class="display-4">
					<?php echo e(__('messages.courses')); ?>

				</h1>
			</div>
		</div>

		<div class="container">
			<?php
				if (session('success')){
					if (session('success')['success'] == false){
						echo '<div class="alert alert-danger" role="alert">' . session('success')['messages'] . '</div>';
					} else {
						echo '<div class="alert alert-success" role="alert">' . session('success')['messages'] . '</div>';
					}
				}
			?>

				<?php if(count($courses) < 1): ?>{
					<p><?php echo e(__('messages.no_course_created')); ?> <a href="<?php echo e(URL::route('courses.create')); ?>"><?php echo e(__('messages.create_course')); ?></a></p>
        <?php else: ?>
				<div class="row">
					<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<div class="col-3">
						<div class="card">
							<img class="card-img-top" src="<?php echo e($course->cover); ?>" alt="Card image cap">
							<div class="card-body">
								<h5 class="card-title">
									<?php echo e($course->title); ?>

								</h5>
							</div>
							<ul class="list-group list-group-flush">
								<li class="list-group-item"><i class="material-icons">person</i>
									<?php echo e(count($course->getStudents)); ?> aluno</li>
								<li class="list-group-item"><i class="material-icons">folder</i>
									<?php echo e(count($course->getModules)); ?> módulos</li>
								<li class="list-group-item"><i class="material-icons">video_library</i>
									<?php echo e(count($course->getLessons)); ?> aulas</li>
							</ul>
							<div class="card-body">
								<a class="card-link" href="<?php echo e(URL::route('courses.edit', ['course_id' =>  $course['id']])); ?>">Editar</a>
								<a class="card-link" href="<?php echo e(URL::route('courses.manage', ['course_id' =>  $course['id']])); ?>">Gerenciar</a>
								<a class="card-link" href="<?php echo e(URL::route('courses.single', ['course' => $course['id']])); ?>">Ver</a>
							</div>
						</div>
					</div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
        <?php endif; ?>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.templates.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>