


<?php $__env->startSection('courseContent'); ?>
    ##parent-placeholder-e404b3344a72528b2ca2df4c1aa2a7efdc076727##
		<div id="course-description" class="pt-3">
			<?php if($course->description == null): ?>
        <p>Nenhuma descrição disponível para este curso.</p>
      <?php else: ?>
        <?php echo $course->description; ?>

      <?php endif; ?>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('courses.panel_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>