<?php $__env->startSection('viewMain'); ?>
    ##parent-placeholder-7ba1feefd9b0e2b57ed1d8023f4f47e24fdb610c##
		<?php echo view('profile/sidebar-profile', ['user' => $user, 'isLoggedProfile' => $isLoggedProfile ]); ?>

		<div class="col s9" id="profile-content">
			<h2 class="profile-page-title">Seguidores</h2>
			<hr>
		</div>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>