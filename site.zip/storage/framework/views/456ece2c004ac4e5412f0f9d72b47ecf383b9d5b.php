<?php $__env->startSection('viewMain'); ?>
    ##parent-placeholder-7ba1feefd9b0e2b57ed1d8023f4f47e24fdb610c##
		<div class="container">
      <div class="mt-5 mb-5" style="text-align:center; width:60%; margin:auto">
			  <h2>Olá, <?php if(auth()->guard()->check()): ?> <?php echo e(Auth::user()->firstname); ?>! <?php endif; ?> <?php if(auth()->guard()->guest()): ?> visitante! <?php endif; ?></h2>
        <p>Esta página ainda está sendo construída, mas matenha o sistema atualizado para ver o mais rápido possível quando tivermos acabado. Por enquanto você pode navegar pelas páginas do site que estão no menu.<?php if(auth()->guard()->guest()): ?> Crie sua conta e faça login para a experiência completa ; )<?php endif; ?></p>
		  </div>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>