


<?php $__env->startSection('viewMain'); ?>
    ##parent-placeholder-7ba1feefd9b0e2b57ed1d8023f4f47e24fdb610c##
		<nav aria-label="breadcrumb" id="page-nav">
			<div class="container">
				<ol class="breadcrumb">
					<li class="breadcrumb-item active" aria-current="page">Galeria</li>
				</ol>
			</div>
		</nav>

		<iframe src="/laravel-filemanager?type=file" style="width: 100%; height: 500px; overflow: hidden; border: none;"></iframe>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.templates.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>