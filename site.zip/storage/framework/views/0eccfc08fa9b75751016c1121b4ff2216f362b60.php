<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
  <link rel="stylesheet" href="<?php echo e(asset("assets/css/bootstrap.min.css ")); ?>">
  <link rel="stylesheet" href="<?php echo e(asset("assets/css/class-room.css ")); ?>">
  <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-3.2.1.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/class-room.js')); ?>"></script>
  <title>Class room</title>
</head>

<body>
  <header>

  </header>
  <nav id="navbar" class="">
      <div class="content-menu">
        <!-- options -->
        <ul class="nav nav-tabs d-flex" id="list-tab" role="tablist">
          <li class="nav-item op-side-menu" data-toggle="tooltip" data-placement="top" title="Grade">
            <a class="nav-link active" id="list-grid" data-toggle="list" href="#grid" role="tab" aria-controls="grid">
              <i class="far fa-edit"></i>
            </a>
          </li>
          <li class="nav-item op-side-menu" data-toggle="tooltip" data-placement="top" title="Arquivos">
            <a class="nav-link" id="list-achive" data-toggle="list" href="#achive" role="tab" aria-controls="achive">
              <i class="fas fa-archive"></i>
              <span class="badge badge-primary"><?php echo e(count($lesson->getMaterials)); ?></span>
            </a>
          </li>
          <li class="nav-item op-side-menu" data-toggle="tooltip" data-placement="top" title="Discussões">
            <a class="nav-link" id="list-dicussion" data-toggle="list" href="#discussion" role="tab" aria-controls="discussion">
              <i class="far fa-comments"></i>
              <span class="badge badge-primary">0</span>
            </a>
          </li>
        </ul>

        <!-- content options -->
        <div class="tab-content" id="nav-tabContent">
          <div id="grid" class="tab-pane fade  show active" role="tabpanel" aria-labelledby="list-grid">
            <div id="modules-list" class="card">
              <?php  $modules = $course->getModules  ?> <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="card module">
                <div class="card-header module-header" id="headingOne">
                  <h5 class="mb-0">
                    <button class="btn btn-link module-name" data-toggle="collapse" data-target="#module-<?php echo e($module->id); ?>" aria-expanded="true"
                      aria-controls="collapseOne">
                      <?php echo e($module->name); ?>

                    </button>
                  </h5>
                </div>

                <div id="module-<?php echo e($module->id); ?>" class="collapse" data-parent="#modules">
                  <div class="card-body">
                    <?php if(count($module->getLessons) > 0): ?>
                    <ul class="list-group">
                      <?php  $lessons = $module->getLessons  ?> <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="lesson list-group-item">
                        <a href="<?php echo e(URL::route('lesson.view_lesson', ['course_id' => $course->id, 'lesson' => $lesson->id])); ?>">
                          <?php echo e($lesson->title); ?>

                        </a> -
                        <span class="lesson-time"><?php echo e($lesson->time); ?></span>
                      </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php else: ?>
                    <div class="no-lesson">Nenhuma aula cadastrada nesse módulo.</div>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>

          <div id="achive" class="tab-pane fade" role="tabpanel" aria-labelledby="list-achive">
            <?php  $materials = $lesson->getMaterials  ?> <?php if(count($materials) > 0): ?>
            <div class="row">
              <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col s12">
                <div class="card">
                  <div class="card-content">
                    <span class="card-title"><?php echo e($material->title); ?></span>
                    <?php echo e($material->content); ?>

                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php else: ?>
            <div class="alert alert-primary d-flex" role="alert">
              Não há materiais para essa aula.
            </div>
            <?php endif; ?>
          </div>

          <div id="discussion" class="tab-pane fade" role="tabpanel" aria-labelledby="list-discussion">
            <div class="alert alert-primary d-flex" role="alert">
              Não há discussões.
            </div>
          </div>
        </div>

        <div class="bottom-menu d-flex">
          <a class="btn btn-block btn-danger" href="<?php echo e(URL::route('courses.single', ['course' => $course->id])); ?>">Sair da sala</a>
        </div>
      </div>
    </nav>
  <main>
    <article>
      <div class="content-lesson  container-fluid">
        <div id="headerArticle" class="header-lesson row">
            <div class="btn-group justify-content-between col-3">
                <button type="button" class="btn" data-toggle="tooltip" data-placement="top" title="Retroceder aula">
                  <i class="fas fa-angle-left"></i>
                </button>
                <button type="button" class="btn" data-toggle="tooltip" data-placement="top" title="Avançar aula">
                  <i class="fas fa-angle-right"></i>
                </button>
            </div>
            <div class="col-6">
          <h1 id="test1" ><?php echo e($lesson->title); ?></h1>
        </div>
        <div class="col-3">
          <button id="btnnavbar" type="button" class="btn">
            <i class="fas fa-bars"></i>
            <i class="fas fa-times d-none"></i>
          </button>
        </div>
        </div>
        <div class="main-lesson">
          <!-- area of midia if available -->
          <div class="lesson-midia">
            <?php echo $video; ?>

          </div>
          <!-- area of article -->
          <?php echo $lesson->content; ?>

        </div>
    </article>
    <!-- Quiz -->
    <article>
        <div class="content-lesson">
          <form action="#" method="post">

          </form>
        </div>
    </article>
  </main>
  <footer></footer>

</body>
</html>
