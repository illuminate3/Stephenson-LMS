<?php $__env->startSection('viewMain'); ?>
    ##parent-placeholder-7ba1feefd9b0e2b57ed1d8023f4f47e24fdb610c##
		<nav aria-label="breadcrumb" id="page-nav">
			<div class="container">
				<ol class="breadcrumb">
					<li class="breadcrumb-item">
						<a href="<?php echo e(URL::route('categories.index')); ?>">
							<?php echo e(__('messages.categories')); ?>

						</a>
					</li>
					<li class="breadcrumb-item active" aria-current="page">
						<?php echo e(__('messages.edit_category')); ?>

					</li>
				</ol>
			</div>
		</nav>

		<div class="jumbotron jumbotron-fluid">
			<div class="container">
				<h1 class="display-4">
					<?php echo e(__('messages.edit_category')); ?>

				</h1>
			</div>
		</div>


		<div class="container">
			<?php
				if (session('success')){
					if (session('success')['success'] == false){
						echo '<div class="alert alert-danger" role="alert">' . session('success')['messages'] . '</div>';
					} else {
						echo '<div class="alert alert-success" role="alert">' . session('success')['messages'] . '</div>';
					}
				}
			?>

			<form method="post" action="<?php echo e(URL::route('categories.update', ['id' => $category['id']])); ?>">
				<div class="form-group">
					<label for="txtName">Nome</label>
					<input type="text" class="form-control" value="<?php echo e($category->name); ?>" id="txtName" placeholder="Nome" name="name">
				</div>

				<div class="form-group">
					<label for="txtSlug">Slug</label>
					<input type="text" class="form-control" value="<?php echo e($category->slug); ?>" id="txtSlug" placeholder="Slug" name="slug">
				</div>

				  <div class="form-group">
					 <label for="exampleFormControlSelect1">Hirarquia</label>
					 <select class="form-control" id="exampleFormControlSelect1" name="level">
							<option value="0" selected><?php echo e(__('messages.primary')); ?></option>
							<?php $__currentLoopData = $categories_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($category_l['id']); ?>"><?php echo e($category_l['name']); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					 </select>
				  </div>

				<button type="submit" class="btn btn-primary btn-lg btn-block mt-3">Editar</button>
				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
				<input type="hidden" value="PUT" name="_method">
			</form>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.templates.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>