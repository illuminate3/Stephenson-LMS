<?php $__env->startSection('viewMain'); ?>
    ##parent-placeholder-7ba1feefd9b0e2b57ed1d8023f4f47e24fdb610c##
    <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <h1 class="display-4"><?php echo e($page->title); ?></h1>
      </div>
    </div>

    <div class="container">
    <?php echo $page->content; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>