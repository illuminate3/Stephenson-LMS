<?php $__env->startSection('viewMain'); ?>
    ##parent-placeholder-7ba1feefd9b0e2b57ed1d8023f4f47e24fdb610c##
		<nav aria-label="breadcrumb" id="page-nav">
			<div class="container">
				<ol class="breadcrumb">
					<li class="breadcrumb-item active" aria-current="page">Estilo</li>
				</ol>
			</div>
		</nav>

		<div class="jumbotron jumbotron-fluid">
		  <div class="container">
		    <h1 class="display-4"><?php echo __('messages.style'); ?></h1>
		  </div>
		</div>

		<div class="container">
				<div class="row">

					<?php $themes = Theme::all(); foreach($themes as $theme){ ?>

		  <div class="col-sm-4">
		    <div class="card">
		      <div class="card-body">
		        <h5 class="card-title"><?php echo $theme->name; ?></h5>
		        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
					<form method="post" action="<?php echo URL::route('style.change_theme'); ?>">
		          	<button class="btn btn-primary" type="submit">Ativar</button>
						<input type="hidden" value="<?php echo $theme->name; ?>" name="theme">
						<input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
					</form>
		      </div>
		    </div>
		  </div>

					<?php } ?>
				</div>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.templates.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>