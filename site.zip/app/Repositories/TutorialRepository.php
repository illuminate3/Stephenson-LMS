<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface TutorialRepository
 * @package namespace App\Repositories;
 */
interface TutorialRepository extends RepositoryInterface
{
    //
}
