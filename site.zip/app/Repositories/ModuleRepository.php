<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ModuleRepository
 * @package namespace App\Repositories;
 */
interface ModuleRepository extends RepositoryInterface
{
    //
}
