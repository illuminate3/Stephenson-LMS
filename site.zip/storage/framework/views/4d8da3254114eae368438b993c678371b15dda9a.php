<!DOCTYPE html>
<html>
<head>
<?php echo $__env->make('head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
    <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div id="content">
        <?php echo $__env->make('courses.panel_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- DIVISA DE CONTEUDO -->
            <?php $__env->startSection('courseContent'); ?>
                <?php echo $__env->yieldSection(); ?>

        <?php echo $__env->make('courses.panel_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
    <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
